SpHc binary distribution - 2026-11-18

Platform: Linux x86-64. Built and checked on Ubuntu 24.04 / WSL Ubuntu.
Requires the system glibc and libstdc++; see RUNTIME.json for symbol versions.
This is not a native Windows .exe package.

Files:
  sphc_main         Original complete construction frontend (local refinements retained).
  sphc_refine_main  Multilevel joint-refinement backend.

Usage:
  ./sphc_main --input design.net --output construction
  ./sphc_refine_main --input design.net --partition construction/partition.txt \
      --topology construction/banks.txt --output refined --tdmax-weight GAMMA

GAMMA is the maximum-delay coefficient used in your experiment.
The --topology input to the backend is the three-column banks.txt file.
--help displays the accepted parameters.

No C++ source files, headers, or build directory are included.
Debug/static symbols were stripped. This does not prevent reverse engineering.
